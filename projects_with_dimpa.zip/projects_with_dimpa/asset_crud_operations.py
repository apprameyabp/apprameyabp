from sqlalchemy import create_engine, MetaData, Table, Column, Integer, String, text
from sqlalchemy.orm import sessionmaker
from sqlalchemy.sql import update
engine = create_engine('sqlite:///asset_management_DB.db',echo=True)

meta = MetaData()

asset_master = Table(
                        'asset_master',meta,
                        Column('id',Integer,primary_key=True),
                        Column('name',String),
                        Column('category', String),
                        Column('brand_name',String),
                        Column('status',String),
                        Column('maintenance_status',String)
                        )
# meta.create_all(engine)


def insert_asset(asset_master_insert_values):
    try:
        Session = sessionmaker(bind=engine)
        session = Session()
        new_asset_record = asset_master.insert().values(
             name = asset_master_insert_values['asset_name'],
        category = asset_master_insert_values['asset_category'],
        brand_name = asset_master_insert_values['asset_brand'],
        status = asset_master_insert_values['asset_status'],
        maintenance_status = asset_master_insert_values['maintenance_status'],
        )
        result = session.execute(new_asset_record)
        session.commit()
        print("Record inserted Successfully.\n{} rows affected.".format(result.rowcount))
    except Exception as e:
        print("Error Occurred: {}".format(e))
        session.rollback()
    
    finally:
        session.close()



def update_asset(asset_update_details):
    Session = sessionmaker(bind=engine)
    session = Session()
    asset = session.query(asset_master).filter_by(id=asset_update_details['asset_id']).first()

    if not asset:
        print('Asset not found with ID {}'.format(asset_update_details['asset_id']))
        return
 
    if asset_update_details.get('asset_name') is not None:
        session.query(asset_master).filter_by(id =asset_update_details['asset_id'] ).update({"name":asset_update_details['asset_name']})
        
    if asset_update_details.get('asset_category') is not None:
        session.query(asset_master).filter_by(id =asset_update_details['asset_id'] ).update({"category":asset_update_details['asset_category']})
        
    if asset_update_details.get('asset_brand_name') is not None:
        session.query(asset_master).filter_by(id =asset_update_details['asset_id'] ).update({"brand_name":asset_update_details['asset_brand_name']})

    if asset_update_details.get('asset_status') is not None:
        session.query(asset_master).filter_by(id =asset_update_details['asset_id'] ).update({"status":asset_update_details['asset_status']})

    if asset_update_details.get('asset_maintenance_status') is not None:
        session.query(asset_master).filter_by(id =asset_update_details['asset_id'] ).update({"maintenance_status":asset_update_details['asset_maintenance_status']})
    session.commit()
    session.close()


def view_all_asset():
    view_all_conn = engine.connect()
    view_all_stmt = text('Select * from asset_master')
    view_all_result = view_all_conn.execute(view_all_stmt).fetchall()
    for row in view_all_result:
        print(row)

def view_specific_search(search_word):
    specific_search_conn = engine.connect()
    specific_search_stmt = text('select * from asset_master where name like :search_word OR category like :search_word OR brand_name like :search_word OR status like :search_word OR maintenance_status like :search_word')
    specific_search_stmt = specific_search_conn.execute(specific_search_stmt, {'search_word': '%' + search_word + '%'})
    specific_search_results = specific_search_stmt.fetchall()
    print(specific_search_results)

def delete_asset(asset_id):
    try:
        Session = sessionmaker(bind=engine)
        session = Session()
        del_stmt = asset_master.delete().where(asset_master.c.id==asset_id)
        result = session.execute(del_stmt)
        print("Rows affected: {}".format(result.rowcount))
        session.commit()
    except Exception as e:
        print("Error occurred: {}".format(e))
        session.rollback()
    finally:
        session.close()



def main():
    # to-insert records
    asset_master_values_dict = {
        "asset_name":"ASUS Zenbook 14X"
,"asset_category":"Laptop","asset_brand":"Asus","asset_status":"Inactive","maintenance_status":"Not Required"
}
    # insert_asset(asset_master_values_dict)
    # view_specific_search('hp')
    # view_all_asset()
    asset_update_details = {
        'asset_id':15,'asset_name':None,'asset_category':None,'asset_brand_name':None,'asset_status':'Inactive','asset_maintenance_status':None
        }
    # update_asset(asset_update_details)
    # delete_asset(11)


if __name__=="__main__":
    main()